package com.spring.test;

import static org.junit.Assert.*;

import org.junit.Test;
import org.springframework.web.servlet.ModelAndView;

import com.spring.beans.HelloUser;

public class HelloUserTest {

	@Test
	public void testHelloUser() {
		HelloUser user=new HelloUser();	
		ModelAndView mav=user.helloUser();
		assertEquals("hellouser", mav);
	}

}
