package com.spring.beans;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class HelloUser {

	@RequestMapping("/hello")
	public ModelAndView helloUser()
	{
		String message="<h2 align='center'>Spring User App</h2><hr>";
		message+="<marquee>Hai Lalitha Good Morning...</marquee>";
		return new ModelAndView("hellouser","message",message);
	}
}
