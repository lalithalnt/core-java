package com.java.test;

import static org.junit.Assert.*;

import org.junit.Test;

import com.java.beans.Addition;

public class AdditionTest {

	Addition addition=new Addition();
	int actualSum=addition.add(2,2);
    int expectedSum=4;
	

	@Test
	public void testAdd() {
		System.out.println("Test case result....");
		System.out.println("Expected Result:"+expectedSum);
		System.out.println("Actual Result:"+actualSum);
		assertEquals(expectedSum, actualSum);
	}

}
