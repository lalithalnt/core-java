package beans;
public class WelcomeUser {

	private String message;

	public WelcomeUser()
	{
		message="Have a good day...";
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}


	public String displayMessage()
	{
		System.out.println(message);
		return message;
	}
}
