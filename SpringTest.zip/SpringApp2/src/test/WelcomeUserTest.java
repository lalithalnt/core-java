package test;


import static org.junit.Assert.*;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import beans.WelcomeUser;


@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration("classpath:resources/spring-config.xml")
public class WelcomeUserTest {

	@Autowired
	protected ApplicationContext ac;
	
	@Test
	public void testDisplayMessage() {
		WelcomeUser wu=new WelcomeUser();
		String expectedMessage="Have a good day...";
		String actualMessage=wu.getMessage();
		//String actualMessage=wu.displayMessage();
		System.out.println("Expected Message is:"+expectedMessage);
		System.out.println("Actual Message is:"+actualMessage);
		assertEquals(expectedMessage,actualMessage);
		
	}

}
